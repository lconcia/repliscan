/*
  FILE: Assertion.hpp
  AUTHOR: Shane Neph & Scott Kuehn
  CREATE DATE: Tue Aug  7 09:12:26 PDT 2007
  PROJECT: Wavelets
*/

/*
Copyright (C) 2007 by Shane Neph, Michael S. Kuehn and John Stamatoyannopoulos,
Department of Genome Sciences, University of Washington.
Contact: sjn@u.washington.edu. All rights reserved

Wavelets software is provided to you at no cost to you. You have the right to
perform, copy, modify, display and distribute this software. If you distribute
Wavelets software or modifications thereof, you agree to grant users the same
rights as are granted to you under this license.

You retain in Wavelets software and any modifications to Wavelets software, the
copyright, trademark, or other notices pertaining to Wavelets as provided by the
author and University of Washington.

If the use of the Wavelets software results in outcomes which will be published,
please specify the version of Wavelets software you used and cite the following
reference:

Percival, D. B. and A. T. Walden (2000)
Wavelet Methods for Time Series Analysis,
Cambridge University Press.

You acknowledge that Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and
University of Washington may develop modifications to Wavelets software that may
be substantially similar to your modifications of Wavelets software, and that
Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and the University of
Washington shall not be constrained in any way by you in the use or management
of such modifications.  You acknowledge the right of Shane Neph, Michael S.
Kuehn, John Stamatoyannopoulos and University of Washington to prepare and
publish modifications to Wavelets software that may be substantially similar or
functionally equivalent to your modifications and improvements, and if you
obtain patent protection for any modification or improvement to Wavelets
software, you agree not to allege or enjoin infringement of your patent by Shane
Neph, Michael S. Kuehn, John Stamatoyannopoulos or the University of Washington.

Any risk associated with using the Wavelets software is with you and your
Institution. This software is provided ``AS IS'' and any express or implied
warranties, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose, are disclaimed. In no
event shall Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos or the
University of Washington be liable for any direct, indirect, incidental,
special, exemplary, or consequential damages (including, but not limited to,
procurement of substitute goods or services; loss of use, data, or profits; or
business interruption) however caused and on any theory of liability, whether
in contract, strict liability, or tort (including negligence or otherwise)
arising in any way out of the use of this software, even if advised of the
possibility of such damage.
*/


// Macro guard
#ifndef ASSERTIONMECHANISM_H
#define ASSERTIONMECHANISM_H

// Files included
#include <string>

namespace Ext {

  //==============================================================================
  // Assert<ExcType>(bool, error)
  //  A simple runtime assertion mechanism; just syntax candy not meant to be
  //  very speedy.  When assertion fails, throw ExcType.
  //==============================================================================
  template <typename ExcType>
  struct Assert {
    /* NOTE: not default constructable */
    
    // Constructor
    Assert(bool b, const std::string& msg) {
      if ( b ) return;
      ExcType e(msg);
      throw(e);
    }
    
    // Constructor overload
    Assert(bool b, const std::string& msg1, const std::string& msg2) {
      Assert<ExcType>(b, msg1 + "\n" + msg2); // Call overload
    }
  };

} // namespace Ext

#endif // ASSERTIONMECHANISM_H
