/*
  FILE: Exception.hpp
  AUTHOR: Shane Neph, Scott Kuehn
  CREATE DATE: Fri Aug 10 15:01:39 PDT 2007
  PROJECT: Wavelets
*/

/*
Copyright (C) 2007 by Shane Neph, Michael S. Kuehn and John Stamatoyannopoulos,
Department of Genome Sciences, University of Washington.
Contact: sjn@u.washington.edu. All rights reserved

Wavelets software is provided to you at no cost to you. You have the right to
perform, copy, modify, display and distribute this software. If you distribute
Wavelets software or modifications thereof, you agree to grant users the same
rights as are granted to you under this license.

You retain in Wavelets software and any modifications to Wavelets software, the
copyright, trademark, or other notices pertaining to Wavelets as provided by the
author and University of Washington.

If the use of the Wavelets software results in outcomes which will be published,
please specify the version of Wavelets software you used and cite the following
reference:

Percival, D. B. and A. T. Walden (2000)
Wavelet Methods for Time Series Analysis,
Cambridge University Press.

You acknowledge that Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and
University of Washington may develop modifications to Wavelets software that may
be substantially similar to your modifications of Wavelets software, and that
Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and the University of
Washington shall not be constrained in any way by you in the use or management
of such modifications.  You acknowledge the right of Shane Neph, Michael S.
Kuehn, John Stamatoyannopoulos and University of Washington to prepare and
publish modifications to Wavelets software that may be substantially similar or
functionally equivalent to your modifications and improvements, and if you
obtain patent protection for any modification or improvement to Wavelets
software, you agree not to allege or enjoin infringement of your patent by Shane
Neph, Michael S. Kuehn, John Stamatoyannopoulos or the University of Washington.

Any risk associated with using the Wavelets software is with you and your
Institution. This software is provided ``AS IS'' and any express or implied
warranties, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose, are disclaimed. In no
event shall Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos or the
University of Washington be liable for any direct, indirect, incidental,
special, exemplary, or consequential damages (including, but not limited to,
procurement of substitute goods or services; loss of use, data, or profits; or
business interruption) however caused and on any theory of liability, whether
in contract, strict liability, or tort (including negligence or otherwise)
arising in any way out of the use of this software, even if advised of the
possibility of such damage.
*/


#ifndef EXCEPTIONTEMPLATE_H
#define EXCEPTIONTEMPLATE_H

#include <exception>
#include <string>

namespace Ext
{

  template <typename ExceptionType, int ErrorID >
  struct Exception 
    : public ExceptionType 
  {
    enum { Value = ErrorID };
    explicit Exception(const std::string& msg) : msg_(msg) { /* */ }
    Exception(const std::string& msg1, const std::string& msg2) : msg_(msg1 + "\n" + msg2) { /* */ }
    virtual ~Exception() throw() { /* */ }
    virtual const char* what() const throw() { return msg_.c_str(); }
  protected:
    Exception() { } // Hack.  look at traits in boost
    std::string msg_;
  };

  // Set of common application errors
  enum MajorErrors
    {
      FileErrorNum,
      UserErrorNum,
      DataErrorNum,
      ProgramErrorNum
    };
  enum FileErrorNums
    {
      InvalidFileErrorNum,
      MissingFileErrorNum
    };
  enum UserErrorNums 
    { 
      InvalidOperationErrorNum
    };
  enum DataErrorNums { };
  enum ProgramErrorNums
    {
      ParameterErrorNum,
      LogicErrorNum,
      ArgumentErrorNum
    };
  
  typedef Exception< std::exception, FileErrorNum > FileError;
  typedef Exception< FileError, InvalidFileErrorNum > InvalidFile;
  typedef Exception< FileError, MissingFileErrorNum > MissingFile;

  typedef Exception< std::exception, UserErrorNum > UserError;
  typedef Exception< UserError, InvalidOperationErrorNum > InvalidOperationError;

  typedef Exception< std::exception, DataErrorNum > DataError;

  typedef Exception< std::exception, ProgramErrorNum > ProgramError;
  typedef Exception< ProgramError, ParameterErrorNum > ParameterError;
  typedef Exception< ProgramError, LogicErrorNum > LogicError;
  typedef Exception< ProgramError, ArgumentErrorNum > ArgumentError;

} // namespace Ext

#endif // EXCEPTIONTEMPLATE_H
