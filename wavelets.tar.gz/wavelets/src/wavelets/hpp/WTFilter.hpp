//=========
// Author:  Shane Neph & Scott Kuehn
// Date:    Fri Sep 21 00:38:19 PDT 2007
// Project: Wavelets
//=========

/*
Copyright (C) 2007 by Shane Neph, Michael S. Kuehn and John Stamatoyannopoulos,
Department of Genome Sciences, University of Washington.
Contact: sjn@u.washington.edu. All rights reserved

Wavelets software is provided to you at no cost to you. You have the right to
perform, copy, modify, display and distribute this software. If you distribute
Wavelets software or modifications thereof, you agree to grant users the same
rights as are granted to you under this license.

You retain in Wavelets software and any modifications to Wavelets software, the
copyright, trademark, or other notices pertaining to Wavelets as provided by the
author and University of Washington.

If the use of the Wavelets software results in outcomes which will be published,
please specify the version of Wavelets software you used and cite the following
reference:

Percival, D. B. and A. T. Walden (2000)
Wavelet Methods for Time Series Analysis,
Cambridge University Press.

You acknowledge that Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and
University of Washington may develop modifications to Wavelets software that may
be substantially similar to your modifications of Wavelets software, and that
Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and the University of
Washington shall not be constrained in any way by you in the use or management
of such modifications.  You acknowledge the right of Shane Neph, Michael S.
Kuehn, John Stamatoyannopoulos and University of Washington to prepare and
publish modifications to Wavelets software that may be substantially similar or
functionally equivalent to your modifications and improvements, and if you
obtain patent protection for any modification or improvement to Wavelets
software, you agree not to allege or enjoin infringement of your patent by Shane
Neph, Michael S. Kuehn, John Stamatoyannopoulos or the University of Washington.

Any risk associated with using the Wavelets software is with you and your
Institution. This software is provided ``AS IS'' and any express or implied
warranties, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose, are disclaimed. In no
event shall Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos or the
University of Washington be liable for any direct, indirect, incidental,
special, exemplary, or consequential damages (including, but not limited to,
procurement of substitute goods or services; loss of use, data, or profits; or
business interruption) however caused and on any theory of liability, whether
in contract, strict liability, or tort (including negligence or otherwise)
arising in any way out of the use of this software, even if advised of the
possibility of such damage.
*/

// Macro Guard
#ifndef WTFILTER_HPP
#define WTFILTER_HPP

// Files included
#include <list>
#include <string>
#include <utility>
#include <vector>

namespace WT {

  struct MODWT { /* */ };
  struct DWT   { /* */ };

  namespace Filter {

    typedef std::vector<double> WaveletFilter;
    typedef std::vector<double> ScalingFilter;

    //=====================
    // FType (filter type)
    //=====================
    enum FType {
      Haar,
      D4, D6, D8, D10, D12, D14, D16, D18, D20,
      LA8, LA10, LA12, LA14, LA16, LA18, LA20,
      BL14, BL18, BL20,
      C6, C12, C18, C24, C30
    };

    //=================
    // selectFilter() : convert a std::string to a FType
    //=================
    FType selectFilterType(const std::string& ftype);

    //================
    // getFilters() : convert an FType into a WaveletFilter & ScalingFilter
    //================
    std::pair< WaveletFilter, ScalingFilter > getFilters(FType ft);

    //=============
    // allFTypes() : return a list of all FType values
    //=============
    std::list< FType > allFTypes();

    //====================
    // allFTypesStrings() : return a list of all 
    //====================
    std::list< std::string > allFTypesStrings();

  } // namespace Filter

} // namespace WT


#include "../cpp/WTFilter.cpp"

#endif // WTFILTER_HPP
