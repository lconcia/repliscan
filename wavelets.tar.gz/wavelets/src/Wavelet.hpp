//=========
// Author:  Shane Neph & Scott Kuehn
// Date:    Fri Sep 21 00:38:19 PDT 2007
// Project: Wavelets
//=========

/*
Copyright (C) 2007 by Shane Neph, Michael S. Kuehn and John Stamatoyannopoulos,
Department of Genome Sciences, University of Washington.
Contact: sjn@u.washington.edu. All rights reserved

Wavelets software is provided to you at no cost to you. You have the right to
perform, copy, modify, display and distribute this software. If you distribute
Wavelets software or modifications thereof, you agree to grant users the same
rights as are granted to you under this license.

You retain in Wavelets software and any modifications to Wavelets software, the
copyright, trademark, or other notices pertaining to Wavelets as provided by the
author and University of Washington.

If the use of the Wavelets software results in outcomes which will be published,
please specify the version of Wavelets software you used and cite the following
reference:

Percival, D. B. and A. T. Walden (2000)
Wavelet Methods for Time Series Analysis,
Cambridge University Press.

You acknowledge that Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and
University of Washington may develop modifications to Wavelets software that may
be substantially similar to your modifications of Wavelets software, and that
Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos and the University of
Washington shall not be constrained in any way by you in the use or management
of such modifications.  You acknowledge the right of Shane Neph, Michael S.
Kuehn, John Stamatoyannopoulos and University of Washington to prepare and
publish modifications to Wavelets software that may be substantially similar or
functionally equivalent to your modifications and improvements, and if you
obtain patent protection for any modification or improvement to Wavelets
software, you agree not to allege or enjoin infringement of your patent by Shane
Neph, Michael S. Kuehn, John Stamatoyannopoulos or the University of Washington.

Any risk associated with using the Wavelets software is with you and your
Institution. This software is provided ``AS IS'' and any express or implied
warranties, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose, are disclaimed. In no
event shall Shane Neph, Michael S. Kuehn, John Stamatoyannopoulos or the
University of Washington be liable for any direct, indirect, incidental,
special, exemplary, or consequential damages (including, but not limited to,
procurement of substitute goods or services; loss of use, data, or profits; or
business interruption) however caused and on any theory of liability, whether
in contract, strict liability, or tort (including negligence or otherwise)
arising in any way out of the use of this software, even if advised of the
possibility of such damage.
*/


// Macro Guard
#ifndef WT_FRAMEWORK_HPP
#define WT_FRAMEWORK_HPP


// Files include
#include "wavelets/hpp/WTBoundaries.hpp"
#include "wavelets/hpp/WTFilter.hpp"
#include "wavelets/hpp/WTOps.hpp"


namespace WT {

  /* Most everything associated with wavelet transformations came from ideas outlined here:
       Percival, D. B. and A. T. Walden (2000) Wavelet Methods for Time Series Analysis, Cambridge University Press.
  */

  //=========
  // modwt() : modified discrete wavelet transform ; calculates wavelet and scaling coefficients
  //=========
  // o Sequence should be a vector<T>, deque<T> or array of T's
  // o VOp and WOp will most often come from wavelets/WTOps.hpp
  // o 'numLevels' is the number of levels you want to calculate
  //=========
  template <
            typename Sequence,      // 'X' contains N measurement values
            typename WaveletFilter, // Filter from wavelets/WTFilter.hpp
            typename ScalingFilter, // Filter from wavelets/WTFilter.hpp
            typename VOp,           // Op called for each scaling coeff calculated (N per level)
            typename WOp            // Op called for each wavelet coeff calculated (N per level)
           >
  void modwt(Sequence& X, const WaveletFilter& wavefilt, const ScalingFilter& scalefilt, int numLevels,
             VOp& vop, WOp& wop);


  //==========
  // imodwt() : inverse modified discrete wavelet transform
  //==========
  //  o Most often used to invert modwt() results
  //  o 'Wj' should be a vector< vector<T> >, or a deque/array analog or combo
  //  o 'wavefilt' and 'scalefilt' should be the same as those used in the original modwt() call
  //==========
  template <
            typename ScalingCoefficients,     // N scaling coefficients
            typename ContWaveletCoefficients, // Container of containers of N wavelet coeff's
            typename WaveletFilter,           // Same as for modwt()
            typename ScalingFilter,           // Same as for modwt()
            typename VOp                      // Op called for each inverse value calculated
           >
  void imodwt(ScalingCoefficients Vj0, ContWaveletCoefficients& Wj, const WaveletFilter& wavefilt,
              const ScalingFilter& scalefilt, VOp& vop);




  /* Note that the smooth() and details() calculated below together sum back to the original Sequence X.
      They are the finer innerworking results of what imodwt() does.  When output as a set of waveforms,
      the smooth and details make up the multiresolution analysis (mra) described in Percival and Walden.
  */

  //==========
  // smooth() : calculates the smooth waveform
  //==========
  // o 'scalefilt' should be the same as was used in calculating 'Vj0' via modwt()
  // o 'numLevels' is the depth used to originally calculated 'Vj0' via modwt()
  //==========
  template <
            typename ScalingCoefficients, // Scaling coefficients calculated from modwt()
            typename ScalingFilter,       // As described for modwt()
            typename SmoothOp             // Op called for each of the N calculated smooth values
           >
  void smooth(ScalingCoefficients& Vj0, const ScalingFilter& scalefilt, int numLevels, SmoothOp& sop);


  //===========
  // details() : calculates the detail waveforms ; concentrating on time rather than memory
  //===========
  //  o 'wavefilt' and 'scalefilt' should be the same as those used in the original modwt() call
  //  o Each operation in 'dops' belongs to a respective container of coefficients and will be called N times
  //===========
  template <
            typename ContWaveletCoefficients, // Container of containers of N wavelet coeff's
            typename WaveletFilter,           // Same as for modwt()
            typename ScalingFilter,           // Same as for modwt()
            typename ContDetailsOps           // Container of ops, one for each wavelet coeff container
           >
  void details(ContWaveletCoefficients& Wj, const WaveletFilter& wavefilt,
               const ScalingFilter& scalefilt, ContDetailsOps& dops);


  //=======
  // mra() : multiresolution analysis ; calculates details and smooth
  //=======
  // o Efficient convenience wrapper for doAll(), specific to details and smooth
  // o Wavelet and scaling coefficients ignored after calculation & use
  // o DetailsOp should self-regulate via 'detailsOp.Reset()'.  See struct PrintLast for a good example.
  //=======
  template <
            typename Sequence,  // 'X' contains the N original values
            typename DetailsOp, // Op called for calculated detail values
            typename SmoothOp   // Op called for calculated smooth values
           >
  void mra(Sequence& X, unsigned int level, Filter::FType filterType,
           DetailsOp& detailsOp, SmoothOp& smoothOp);


  //=========
  // doAll() : calculates everything from scratch, giving opportunity for all output operations
  //=========
  // o All possible ops available: wavelet coeff's, scaling coeff's, details and smooth
  // o DetailsOp should self-regulate via 'detailsOp.Reset()'.  See struct PrintLast for a good example.
  //=========
  template <
            typename Sequence,              // 'X' contains the N original values
            typename WaveletCoefficientOps, // Op called for calculated wavelet coeff values (N per level)
            typename DetailsOp,             // Op called for calculated details values (N per level)
            typename ScalingCoefficientOp,  // Op called for calculated scaling coeff values
            typename SmoothOp               // Op called for calculated smooth values
           >
  void doAll(Sequence& X,
             unsigned int level,
             Filter::FType filterType,
             WaveletCoefficientOps& waveletOp,
             DetailsOp& detailsOp,
             ScalingCoefficientOp& scalingOp,
             SmoothOp& smoothOp);

} // namespace WT


#include "wavelets/cpp/WT.cpp"

#endif // WT_FRAMEWORK_HPP
